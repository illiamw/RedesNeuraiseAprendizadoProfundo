-------------- README ---------------

Arquivos:
P1WilliamFerreira9847599.pdf - Última execução completa do notebook e exportada como PDF via latex.
./JupyterNotebook            - Arquivos do Jupyter Notebook com o ultimo checkpoint.
	-> /Projeto1.ipynb   - Arquivo notebook para executar os scripts

Obs: Com o limite de upload 25MB, removi a base de dados do envio, logo espera-se que tais arquivos 
seram armazenados em ./JupyterNotebook/train.csv e ./JupyterNotebook/test.csv