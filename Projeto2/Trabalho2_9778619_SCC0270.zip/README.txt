Trabalho realizado por Beatriz Campos de Almeida de Castro Monteiro, número USP: 9778619

Os arquivos contidos nessa pasta consistem em um código no formato notebook e dois arquivos .csv de leitura utilizados no código como treino (train_32x32.mat) e teste (test_32x32.mat) de redes neurais.